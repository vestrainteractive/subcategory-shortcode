# subcategory-shortcode

Displays a list of subcategories of the current category with thumbnails.  Requires the plugin "Categories Images" to function.
